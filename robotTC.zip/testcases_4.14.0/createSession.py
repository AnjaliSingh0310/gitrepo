from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium import webdriver
from Selenium2Library import Selenium2Library
from browsermobproxy import Server
from pprint import pprint
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import json
import time
import os, signal
import calendar;
import socket
     
def get_free_tcp_port():
       tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
       tcp.bind(('', 0))
       addr, port = tcp.getsockname()
       tcp.close()
       return port

def cluster1session():
    MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
    
    # Configure Browsermob-Proxy server
    newPort = {'port': 8082}  # Hardcoded port number
    mobserver = Server(MOBPATH, options=newPort)
    mobserver.start()
    proxy = mobserver.create_proxy()
    
    # Configure ChromeOptions
    chrome_options = webdriver.ChromeOptions()
    ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
    chrome_options.add_argument(f'user-agent={ua}')
    chrome_options.add_argument('--headless')
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--ignore-certificate-errors')
    
    # Configure Chrome desired capabilities
    capabilities = DesiredCapabilities.CHROME.copy()
    capabilities['acceptSslCerts'] = True
    capabilities['acceptInsecureCerts'] = True
    
    # Start WebDriver session
    driver = webdriver.Chrome(options=chrome_options, desired_capabilities=capabilities)
    proxy.new_har('cluster1session', options={"captureContent":True, "captureBinaryContent":True,"captureHeaders":True})
    try:
        # Navigate to URL
        driver.get('http://10.10.70.163:9010/app/index.html')
        time.sleep(3)
        #driver.find_element(By.XPATH, '//a[text()="Home"]').click() 
        # Execute JavaScript to flush data
        sid=driver.execute_script("return window.CAVNV.sid;")
        print(sid)
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        time.sleep(2)
        
        # Capture network traffic (HAR file)
        cluster1sessionHar = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/cluster1session.har", "w")
        f.write(cluster1sessionHar)
        f.close()
    
    finally:
        # Close WebDriver session and stop Browsermob-Proxy server
        driver.quit()
        mobserver.stop()

def cluster2session():
    MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"

    # Configure Browsermob-Proxy server
    newPort = {'port': 8082}  # Hardcoded port number
    mobserver = Server(MOBPATH, options=newPort)
    mobserver.start()
    proxy = mobserver.create_proxy()

    # Configure ChromeOptions
    chrome_options = webdriver.ChromeOptions()
    ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
    chrome_options.add_argument(f'user-agent={ua}')
    chrome_options.add_argument('--headless')
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--ignore-certificate-errors')
    chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
    # Configure Chrome desired capabilities
    capabilities = DesiredCapabilities.CHROME.copy()
    capabilities['acceptSslCerts'] = True
    capabilities['acceptInsecureCerts'] = True

    # Start WebDriver session
    driver = webdriver.Chrome(options=chrome_options, desired_capabilities=capabilities)
    proxy.new_har('cluster2session', options={"captureContent":True, "captureBinaryContent":True,"captureHeaders":True})
    try:
        # Navigate to URL
        driver.get('http://10.10.70.107:9001/app/index.html')
        time.sleep(3)
        #driver.find_element(By.XPATH, '//a[text()="Home"]').click()
        # Execute JavaScript to flush data
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        time.sleep(2)

        # Capture network traffic (HAR file)
        cluster2sessionHar = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/cluster2session.har", "w")
        f.write(cluster2sessionHar)
        f.close()

    finally:
        # Close WebDriver session and stop Browsermob-Proxy server
        driver.quit()
        mobserver.stop()
def parseHarDataWithData(harName,requestName,*args):
        harName =  "/home/cavisson/work/robotSuite/harfile/"+harName+".har"
        #harName =  "/home/cavisson/work/robotSuite/harfile/HomePageWithPostData.har"
        print (harName)
        sp = len(args)     
        # Opening JSON file 
        f = open(harName,)
        data = json.load(f)
        f.close()
        entryList= data["log"]["entries"];
        print (len(entryList))
        hData = []
        for entry in entryList:
                urlVal = entry["request"]["url"]
                if requestName in urlVal:
                #print (urlVal)
                 rStatus = entry["request"]["postData"]["text"]
                 if sp > 0:
                        print("in if")
                        searchPattern = args[0]
                        if searchPattern in rStatus:
                                 d = [urlVal,rStatus]
                                 hData.append(d)
                 else:
                     print("in else")
                     d = [urlVal,rStatus]
                     hData.append(d)
        return hData

#This should be last method that will kill the browsermobproxy
def check_kill_process(pstring):
    for line in os.popen("ps ax | grep " + pstring + " | grep -v grep"):
        fields = line.split()
        pid = fields[0]
        os.kill(int(pid), signal.SIGKILL)

cluster1session()
#cluster2session()
#check_kill_process("browsermo")
#check_kill_process("chrome")





































