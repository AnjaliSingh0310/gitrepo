from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
import time 
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities

def CustomNumber():
     chrome_options = webdriver.ChromeOptions()
     ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
     chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
     chrome_options.add_argument('--headless')
     chrome_options.add_argument("--disable-dev-shm-usage")
     chrome_options.add_argument('--no-sandbox')
     chrome_options.add_argument('--ignore-certificate-errors')
     capabilities = DesiredCapabilities.CHROME.copy()
     capabilities['acceptSslCerts'] = True
     capabilities['acceptInsecureCerts'] = True
     driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)
     driver.get("https://10.10.70.107:9002/app/index.html")
     time.sleep (5)
     driver.maximize_window()
     wait = WebDriverWait(driver, 10)
     driver.set_window_size(1400, 900)
     shop=driver.find_element(By.CSS_SELECTOR, "a#dropdown04")
     action = ActionChains(driver);
     action.move_to_element(shop).perform()
     hovershop=driver.find_element(By.CSS_SELECTOR, "#ftco-nav > ul > li.nav-item.dropdown > div > a:nth-child(1)")
     hovershop.click()
     driver.execute_script("cav_nv_log_customMetrics('SAorderid', 15)")
     time.sleep(5)
     sid=driver.execute_script("return window.CAVNV.sid;")
     driver.execute_script("window.CAVNV.flush_all();")
     driver.execute_script("window.CAVNV.sbqueue.flush();")
     time.sleep(5)

def CustomDouble():
    chrome_options=webdriver.ChromeOptions()
    ua='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
    chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
    chrome_options.add_argument("--headless")
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--ignore-certificate-errors')
    capabilities = DesiredCapabilities.CHROME.copy()
    capabilities['acceptSslCerts'] = True
    capabilities['acceptInsecureCerts'] = True
    driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)
    driver.get("https://10.10.70.107:9002/app/index.html")
    time.sleep(5)
    driver.set_window_size(1400 , 900)
    wait=WebDriverWait(driver , 10)
    shop=driver.find_element(By.CSS_SELECTOR, "a#dropdown04")
    action = ActionChains(driver);
    action.move_to_element(shop).perform()
    hovershop=driver.find_element(By.CSS_SELECTOR, "#ftco-nav > ul > li.nav-item.dropdown > div > a:nth-child(1)")
    hovershop.click()
    driver.execute_script("cav_nv_log_customMetrics('SAprice', 15.89)")
    time.sleep(5)
    sid=driver.execute_script("return window.CAVNV.sid;")
    driver.execute_script("window.CAVNV.flush_all();")
    driver.execute_script("window.CAVNV.sbqueue.flush();")
    time.sleep(5)
def CustomNumbers():
     chrome_options = webdriver.ChromeOptions()
     ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
     chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
     chrome_options.add_argument('--headless')
     chrome_options.add_argument("--disable-dev-shm-usage")
     chrome_options.add_argument('--no-sandbox')
     chrome_options.add_argument('--ignore-certificate-errors')
     capabilities = DesiredCapabilities.CHROME.copy()
     capabilities['acceptSslCerts'] = True
     capabilities['acceptInsecureCerts'] = True
     driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)
     driver.get("https://10.10.40.23:4434/app/index.html")
     time.sleep (5)
     driver.maximize_window()
     wait = WebDriverWait(driver, 10)
     driver.set_window_size(1400, 900)
     shop=driver.find_element(By.CSS_SELECTOR, "a#dropdown04")
     action = ActionChains(driver);
     action.move_to_element(shop).perform()
     hovershop=driver.find_element(By.CSS_SELECTOR, "#ftco-nav > ul > li.nav-item.dropdown > div > a:nth-child(1)")
     hovershop.click()
     driver.execute_script("cav_nv_log_customMetrics('SAorderid', 15)")
     time.sleep(5)
     sid=driver.execute_script("return window.CAVNV.sid;")
     driver.execute_script("window.CAVNV.flush_all();")
     driver.execute_script("window.CAVNV.sbqueue.flush();")
     time.sleep(5)
CustomNumbers()     
