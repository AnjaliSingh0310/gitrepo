from pymongo import MongoClient

ip='10.10.50.62:27017'
Uname='cavisson'
passw='Cavisson!'
dbname='test'


def checkcollectionspresence():
# Connect to MongoDB with username and password
       client = MongoClient(ip, username=Uname, password=passw)
       db = client[dbname]
       collections = db.list_collection_names()
       collection_names_to_check = ['RUM_CONFIG_PENDING_test','RUM_CONFIG_test','RUM_META_DATA_CHANGES_test']
       all_present = all(collection_name in collections for collection_name in collection_names_to_check)
       client.close()
       if all_present:
           return 1
       else:
           return 0


def databaselist():
      client = MongoClient(ip, username=Uname, password=passw)
      dbnames = client.list_database_names()
      print(dbnames)
      dblists=['admin','local','test']
      all_present = all(dbname in dbnames for dbname in dblists)
      client.close()
      if all_present:
          return 1
      else:
          return 0

def Records():
      client = MongoClient(ip, username=Uname, password=passw)
      db = client[dbname]
      col = db["RUM_CONFIG_test"]
      x = col.find_one()
      client.close()
      expected_values = {'ENABLE_RUM': '1 /test_rum','RUM_SID_EXPIRY_TIMEOUT': '180','RUM_CLIENT_ID': 'test'}
      for key, value in expected_values.items():
          if key not in x or x[key] != value:
              return 0
      return 1
            


#print(Records())
