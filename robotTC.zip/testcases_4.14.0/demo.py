*** Settings ***
Library           Browser
Library           RPA.JSON

*** Variables ***
${HAR_FILE_PATH}=    ${OUTPUT_DIR}${/}har.har

*** Tasks ***
Record HAR file
    Configure HAR
    New Page    https://developer.mozilla.org/
    Parse HAR

*** Keywords ***
Configure HAR
    ${har_config}=
    ...    Create Dictionary
    ...    path=${HAR_FILE_PATH}
    ...    omitContent=True
    New Context    recordHar=${har_config}

Parse HAR
    ${json}=    Load Json From File    ${HAR_FILE_PATH}
    ${urls}=    Get Values From Json    ${json}    $..url
