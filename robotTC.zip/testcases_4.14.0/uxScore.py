from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium import webdriver
from Selenium2Library import Selenium2Library
from browsermobproxy import Server
from pprint import pprint
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
import json
import time
import os, signal
import calendar;
import socket
     
def get_free_tcp_port():
       tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
       tcp.bind(('', 0))
       addr, port = tcp.getsockname()
       tcp.close()
       return port

def uxsession():
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        '''p = get_free_tcp_port()
        newPort = {'port': p}'''
        newPort = {'port': 8082}
        #newPort = {'port': 8082}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()
        chrome_options = webdriver.ChromeOptions()
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)
        proxy.new_har('cluster1session', options={"captureContent":True, "captureHeaders": True})
        #proxy.new_har('homePage')
        driver.get('http://10.10.30.247:9050/instument0.2/index.html')
        #driver.get('http://10.10.40.23:8004/app/index.html')
        action = ActionChains(driver);
        driver.maximize_window()
        driver.set_window_position(0, 0)
        driver.set_window_size(1400, 900)
        time.sleep(10)
        driver.save_screenshot("image.png")
        shop=driver.find_element(By.CSS_SELECTOR, "a#dropdown04")
        #shop=driver.find_element(By.CSS_SELECTOR, "a.nav-link[href=\"cart.html\"]")
        #driver.implicitly_wait(10)
        #ActionChains(driver).move_to_element(shop).click(shop).perform()
        #shop.click()
        #shop=driver.find_element(By.xpath("//*[@id="ftco-nav"]/ul/li[2]/div/a[1]"))
       # time.sleep(10)
        driver.save_screenshot("image1.png")
        action.move_to_element(shop).perform()
        #time.sleep(2)
        #driver.find_element(By.xpath("//*[@id="dropdown04"]")).click()
        #hovershop=driver.find_element(By.CSS_SELECTOR, "#ftco-nav > ul > li.nav-item.dropdown > div > a:nth-child(1)")
        #hovershop.click()
        #shop=driver.find_element(By.CSS_SELECTOR, "a#dropdown04")
        #action.move_to_element(shop).perform()
        cart=driver.find_element(By.CSS_SELECTOR, "#ftco-nav > ul > li.nav-item.dropdown.show > div > a:nth-child(3)")
        driver.save_screenshot("image2.png")
        cart.click()
        driver.save_screenshot("image5.png")
        ajax=driver.find_element(By.CSS_SELECTOR, "#ajaxEvent")
        ajax.click()
        js=driver.find_element(By.CSS_SELECTOR, "#jse")
        js.click()
        shop=driver.find_element(By.CSS_SELECTOR, "a#dropdown04")
        driver.save_screenshot("image3.png")
        action.move_to_element(shop).perform()
        hovershop=driver.find_element(By.CSS_SELECTOR, "#ftco-nav > ul > li.nav-item.dropdown > div > a:nth-child(1)")
        hovershop.click()
        driver.save_screenshot("image4.png")
        sid=driver.execute_script("return window.CAVNV.sid;")
        driver.execute_script("window.CAVNV.flush_all();")
        time.sleep(2)
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        time.sleep(2)
        #pprint(proxy.har) # returns [] if using headless
        cluster1sessionHar = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/cluster1session.har", "w")
        f.write(cluster1sessionHar)
        f.close()
        driver.close()
        mobserver.stop()


def parseHarData(harName,requestName,*args):
    harName =  "/home/cavisson/work/robotSuite/harfile/"+harName+".har"
        #harName =  "/home/cavisson/work/robotSuite/harfile/HomePageCSI.har"
    print (harName)
        # Opening JSON file
    f = open(harName,)
    data = json.load(f)
    f.close()
    entryList= data["log"]["entries"];
    print (len(entryList))
    hData = [];
    for entry in entryList:
        urlVal = entry["request"]["url"]
        if requestName in urlVal:
            print (urlVal)
            if len(args) == 0:
                rStatus = entry["response"]["status"]
                d = [urlVal,rStatus]
                hData.append(d)
            else:
                searchParameter = args[0]
                rParam = entry["request"][searchParameter]
                print(rParam)
                d = [urlVal,rParam]
                hData.append(d)
    return hData


def parseHarDataWithData(harName,requestName,*args):
        harName =  "/home/cavisson/work/robotSuite/harfile/"+harName+".har"
        #harName =  "/home/cavisson/work/robotSuite/harfile/HomePageWithPostData.har"
        print (harName)
        sp = len(args)
        # Opening JSON file
        f = open(harName,)
        data = json.load(f)
        f.close()
        entryList= data["log"]["entries"];
        print (len(entryList))
        hData = [];
        for entry in entryList:
            urlVal = entry["request"]["url"]
            if requestName in urlVal:
                 #print (urlVal)
                 rStatus = entry["request"]["text"]
                 if sp > 0:
                        print("in if")
                        searchPattern = args[0]
                        if searchPattern in rStatus:
                                 d = [urlVal,rStatus]
                                 hData.append(d)
                 else:
                    print("in else")
                    d = [urlVal,rStatus]
                    hData.append(d)

        return hData

#This should be last method that will kill the browsermobproxy
def check_kill_process(pstring):
    for line in os.popen("ps ax | grep " + pstring + " | grep -v grep"):
        fields = line.split()
        pid = fields[0]
        os.kill(int(pid), signal.SIGKILL)


#check_kill_process("browsermo")
#check_kill_process("chrome")
uxsession()

