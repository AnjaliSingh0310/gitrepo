import gzip
def getPageDump():
	with gzip.open('/home/cavisson/work/robotSuite/capture_823232689631920130_1.gz', 'r') as fin:
              pData = fin.read()
              return pData

def getFeedback():
	 with gzip.open('/home/cavisson/work/robotSuite/fbDump.gz', 'r') as fin:
                fbData = fin.read()
                return fbData
def getUseraction():
         with gzip.open('/home/cavisson/work/robotSuite/useraction_834778785789247489_1.json.gz', 'r') as fin:
                uaData = fin.read()
                return uaData

