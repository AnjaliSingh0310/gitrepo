import socket
from browsermobproxy import Server
from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

def get_free_tcp_port():
    tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    tcp.bind(('', 0))
    port = tcp.getsockname()[1]  # Extract the port number
    tcp.close()
    return port

def FASession():
    variationData = []
    MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
    
    newPort = {'port': get_free_tcp_port()}
    
    mobserver = Server(MOBPATH, options=newPort)
    mobserver.start()
    proxy = mobserver.create_proxy()
    
    chrome_options = webdriver.ChromeOptions()
    ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
    chrome_options.add_argument('user-agent=' + ua)
    chrome_options.add_argument('--headless')
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--ignore-certificate-errors')
    chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
    
    capabilities = DesiredCapabilities.CHROME.copy()
    capabilities['acceptSslCerts'] = True
    capabilities['acceptInsecureCerts'] = True
    
    driver = webdriver.Chrome(chrome_options=chrome_options, desired_capabilities=capabilities)
    driver.get('http://10.10.30.247:9050/instument0.2/index.html')
    time.sleep(5)
    driver.maximize_window()
    action=ActionChains(driver)
    action.move_to_element(driver.find_element(By.XPATH,"//a[text()='Shop']")).perform()
    driver.find_element(By.XPATH,"//a[@href='checkout.html']").click()
    time.sleep(2)


