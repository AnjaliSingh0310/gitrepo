from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium import webdriver
from browsermobproxy import Server
import json
import time
import os
import signal

def start_browsermob_proxy(port):
    MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
    options = {'port': port}
    mobserver = Server(MOBPATH, options=options)
    mobserver.start()
    return mobserver

def stop_browsermob_proxy(proxy_server):
    if proxy_server:
        proxy_server.stop()

def capture_session(proxy, url, har_file):
    proxy.new_har('session', options={"captureContent": True, "captureBinaryContent": True, "captureHeaders": True})
    driver = None
    try:
        chrome_options = webdriver.ChromeOptions()
        chrome_options.add_argument('--headless')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--ignore-certificate-errors')

        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True

        driver = webdriver.Chrome(options=chrome_options, desired_capabilities=capabilities)
        driver.get(url)
        time.sleep(3)
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        time.sleep(2)

        har_data = json.dumps(proxy.har)
        with open(har_file, "w") as f:
            f.write(har_data)

    finally:
        if driver:
            driver.quit()

def cluster1session():
    proxy_port = 8081
    proxy_server = start_browsermob_proxy(proxy_port)
    try:
        url = 'https://10.10.70.163:9011/app/index.html'
        capture_session(proxy_server.create_proxy(), url, "/home/cavisson/work/robotSuite/harfile/cluster1session.har")
    finally:
        stop_browsermob_proxy(proxy_server)

def cluster2session():
    proxy_port = 8082
    proxy_server = start_browsermob_proxy(proxy_port)
    try:
        url = 'https://10.10.70.107:9002/app/index.html'
        capture_session(proxy_server.create_proxy(), url, "/home/cavisson/work/robotSuite/harfile/cluster2session.har")
    finally:
        stop_browsermob_proxy(proxy_server)

def main():
    cluster1session()
    cluster2session()

if __name__ == "__main__":
    main()

