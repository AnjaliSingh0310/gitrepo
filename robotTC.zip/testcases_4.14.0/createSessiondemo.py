from selenium.webdriver import ChromeOptions, DesiredCapabilities
from selenium import webdriver
from browsermobproxy import Server
import json
import time

def completeSession():
    try:
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        newPort = {'port': 8082}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()

        chrome_options = ChromeOptions()
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=' + ua)
        chrome_options.add_argument('--headless')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True

        driver = webdriver.Chrome(chrome_options=chrome_options, desired_capabilities=capabilities)
        proxy.new_har('cluster1session', options={"captureContent":True, "captureBinaryContent":True,"captureHeaders":True})
        driver.get('https://10.10.70.107:9002/app/index.html')
        time.sleep(3)
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        time.sleep(5)  # Adjust sleep time as needed

        cluster1sessionHar = json.dumps(proxy.har)
        print("Har Response:", cluster1sessionHar)  # Debugging

        # Write response to file
        with open("/home/cavisson/work/robotSuite/harfile/cluster1session.har", "w") as f:
            json.dump(cluster1sessionHar, f)

        driver.close()
        mobserver.stop()
    except Exception as e:
        print("An error occurred:", e)

completeSession()

