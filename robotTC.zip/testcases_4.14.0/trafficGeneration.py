from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium import webdriver
#from Selenium2Library import Selenium2Library
#from Selenium import Selenium2Library
from browsermobproxy import Server
from pprint import pprint
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import json
import sys
import calendar;
import time
import threading
import os, signal

def completeSession():
   try:
        chrome_options = webdriver.ChromeOptions()
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--ignore-certificate-errors')
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)
        driver.get('http://10.10.30.247:9050/instument0.2/index.html')
        time.sleep(3)
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        driver.find_element_by_css_selector('.oi.oi-menu').click()
        time.sleep(1)
        driver.find_element_by_css_selector('[href="cart.html"].nav-link').click()
        #driver.implicitly_wait(10)     
        time.sleep(10)
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        driver.save_screenshot("sambit.png")
        driver.execute_script("window.document.querySelector('a.btn').scrollIntoView()")
        driver.execute_script("window.document.querySelector('a.btn').click()")
        time.sleep(1)
        driver.execute_script("window.scrollBy(0,500)")
        driver.save_screenshot("a.png")
        wait = WebDriverWait(driver, 10)
        element = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, '[name="fname"]')))
        driver.find_element_by_css_selector("[name='fname']").send_keys("Robot")
        driver.find_element_by_css_selector("[name='lname']").send_keys("Data")
        driver.find_element_by_css_selector("[name='street']").send_keys("Noida")
        driver.find_element_by_css_selector("[name='zip']").send_keys("201301")
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        driver.find_element_by_id("ocbtn").click()
        time.sleep(3)
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        sid=driver.execute_script("return window.CAVNV.sid;")
        timestr = time.strftime("%Y%m%d-%H%M")
        filename = timestr+'.txt'
        if os.path.exists("/home/cavisson/work/webapps/nvbackend/sessionGen/"+filename):
                append_write = 'a' # append if already exists
        else:
                append_write = 'w' # make a new file if not
        sidFile = open("/home/cavisson/work/webapps/nvbackend/sessionGen/"+filename,append_write)
        sidFile.write(sid + '\n')
        sidFile.close()
        driver.quit()

   except Exception as e:
       driver.quit()
       print("Session Not Generated")
       print(e)

def singlePageSession():
        chrome_options = webdriver.ChromeOptions()
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--ignore-certificate-errors')
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)
        driver.get('http://10.10.30.247:9050/instument0.2/cart.html')
        time.sleep(5)
        sid=driver.execute_script("return window.CAVNV.sid;");
        timestr = time.strftime("%Y%m%d-%H%M")
        filename = timestr+'.txt'
        if os.path.exists("/home/cavisson/work/webapps/nvbackend/sessionGen/"+filename):
            append_write = 'a' # append if already exists
        else:
            append_write = 'w' # make a new file if not
        sidFile = open("/home/cavisson/work/webapps/nvbackend/sessionGen/"+filename,append_write)
        sidFile.write(sid + '\n')
        sidFile.close()
        print(sid)
        driver.quit()

def generatDynamicLoad(N,st):
        print ("helloooo")
        t = time.localtime()
        current_time = time.strftime("%H:%M:%S", t)
        #N = 5   # Number of browsers to spawn
        N = int(N)
        thread_list = list()
        # Start test
        ts = calendar.timegm(time.gmtime())
        stimeStampFile = open("/home/cavisson/work/webapps/nvbackend/sessionGen/sessionStartTime.txt",'w')
        stimeStampFile.write(str(ts))
        stimeStampFile.close()

        if st == "complete":
                print("Complete Session")
                for i in range(N):
                    t = threading.Thread(name='Test {}'.format(i), target=completeSession)
                    t.start()
                    time.sleep(1)
                    print(t.name + ' started!')
                    thread_list.append(t)
        else:
                print("Single Page Session")
                for i in range(N):
                    t = threading.Thread(name='Test {}'.format(i), target=singlePageSession)
                    t.start()
                    time.sleep(1)
                    prin(t.name + ' started!')
                    thread_list.append(t)

	

        # Wait for all thre<ads to complete
        for thread in thread_list:
            thread.join()

        print('Test completed!')
        t = time.localtime()
        current_time = time.strftime("%H:%M:%S", t)
        print(current_time)
        ts = calendar.timegm(time.gmtime())
        stimeStampFile = open("/home/cavisson/work/webapps/nvbackend/sessionGen/sessionEndTime.txt",'w')
        stimeStampFile.write(str(ts))
        stimeStampFile.close()


#print 'Argument List:', str(sys.argv[2])
#count = int(sys.argv[1]) if len(sys.argv) > 1 else  0
#sessType = sys.argv[2] if len(sys.argv) > 1 else  0

#if count == 0:
#   sys.exit()

#print (sessType)
#generatDynamicLoad(count,sessType)
generatDynamicLoad("1","complete")
