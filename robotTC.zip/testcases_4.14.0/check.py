from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium import webdriver
from Selenium2Library import Selenium2Library
from browsermobproxy import Server
from pprint import pprint
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import json
import sys
import calendar;
import time
import threading
import os, signal
import socket

def get_free_tcp_port():
    tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    tcp.bind(('', 0))
    addr, port = tcp.getsockname()
    tcp.close()
    return port



def CPJSON():
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        newPort = {'port': 8082}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()
        chrome_options = webdriver.ChromeOptions()
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)
        proxy.new_har('indexCP', options={"captureContent":True, "captureHeaders":True})
        driver.get('http://10.10.30.247:9050/instument0.2/index.html')
        driver.maximize_window()
        time.sleep(5)
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        indexCP = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/indexCP.har", "w")
        f.write(indexCP)
        f.close()
        driver.close()
        mobserver.stop()

def check_kill_process(pstring):
    for line in os.popen("ps ax | grep " + pstring + " | grep -v grep"):
        fields = line.split()
        pid = fields[0]
        os.kill(int(pid), signal.SIGKILL)



CPJSON();
