import json
import time
import os, signal

#This should be last method that will kill the browsermobproxy
def check_kill_process(pstring):
    for line in os.popen("ps -ef | pgrep -f "+pstring):
        fields = line.split()
        pid = fields[0]
        os.kill(int(pid), signal.SIGKILL)
#check_kill_process("chrome")
#check_kill_process("browser")
