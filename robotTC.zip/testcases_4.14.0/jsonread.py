import  json
import  jsonpath

def readlocatorfromjson(selector):
    #f=open('../../Element.json')
   with open("/home/cavisson/work/webapps/nvbackend/testcases/Dashboard.json", "r") as read_file:
        data = json.load(read_file)
    #res=json.loads("f.read()")
        print (data)
   value= jsonpath.jsonpath(data,selector)
   return value[0]
#readlocatorfromjson(".categories-item-drag.nav-active")
