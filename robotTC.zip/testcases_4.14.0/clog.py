from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium import webdriver
from Selenium2Library import Selenium2Library
from browsermobproxy import Server
from pprint import pprint
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import json
import time
import os, signal
import socket

def createsessionclog():
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        newPort = {'port': 8084}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()

        chrome_options = webdriver.ChromeOptions()

#       user_agent = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.50 Safari/537.36'
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
#       chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)
        proxy.new_har('cartclog', options={"captureContent":True, "captureHeaders":False})
        try:
           driver.get('http://10.10.30.247:9050/instument0.2/index.html')
           driver.maximize_window()
           time.sleep(7)
           driver.execute_script("console.log('robotlog');")
           driver.execute_script("console.warn('robotwarn');")
           driver.execute_script("console.info('robotinfo');")
           driver.execute_script("console.error('roboterror');")
           time.sleep(7)
           sT= driver.execute_script("return window.CAVNV.session_start_time;")
           print(sT)
           driver.execute_script("window.CAVNV.flush_all();")
           driver.execute_script("window.CAVNV.sbqueue.flush();")
           time.sleep(2)
           cartclogHar = json.dumps(proxy.har)
           f = open("/home/cavisson/work/robotSuite/harfile/cartclog.har", "w")
           f.write(cartclogHar)
           f.close()
           driver.close()
           mobserver.stop()
           return sT
        except Exception as e:
           print(e)

def createsessionclog1():
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        newPort = {'port': 8084}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()

        chrome_options = webdriver.ChromeOptions()

#       user_agent = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.50 Safari/537.36'
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
#       chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)
        proxy.new_har('cartclog1', options={"captureContent":True, "captureHeaders":False})
        driver.get('http://10.10.30.247:9050/instument0.2/index.html')
        driver.maximize_window()
        time.sleep(7)
        driver.execute_script("console.log('robotlog');")
        driver.execute_script("console.warn('robotwarn');")
        driver.execute_script("console.info('robotinfo');")
        driver.execute_script("console.error('roboterror');")
        driver.execute_script("console.log('robotlog1');")
        driver.execute_script("console.warn('robotwarn1');")
        driver.execute_script("console.info('robotinfo1');")
        driver.execute_script("console.error('roboterror1');")
        driver.execute_script("console.log('robotlog1');")
        driver.execute_script("console.warn('robotwarn1');")
        driver.execute_script("console.info('robotinfo1');")
        driver.execute_script("console.error('roboterror1');")
        time.sleep(7)
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        time.sleep(2)
        cartclog1Har = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/cartclog1.har", "w")
        f.write(cartclog1Har)
        f.close()
        driver.close()
        mobserver.stop()

def createsessionclog3():
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        newPort = {'port': 8084}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()

        chrome_options = webdriver.ChromeOptions()

#       user_agent = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.50 Safari/537.36'
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
#       chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)
        proxy.new_har('cartclog3', options={"captureContent":True, "captureHeaders":False})
        driver.get('http://10.10.30.247:9050/instument0.2/index.html')
        driver.maximize_window()
        time.sleep(7)
        driver.execute_script("console.log('robotlog');")
        driver.execute_script("console.log('robotlog');")
        driver.execute_script("console.info('robotinfo');")
        driver.execute_script("console.info('robotinfo');")
        driver.execute_script("console.warn('robotwarn');")
        driver.execute_script("console.warn('robotwarn');")
        driver.execute_script("console.error('roboterror');")
        driver.execute_script("console.error('roboterror');")
        time.sleep(7)
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        time.sleep(2)
        cartclog3Har = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/cartclog3.har", "w")
        f.write(cartclog3Har)
        f.close()
        driver.close()
        mobserver.stop()

def createsessionclog4():
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        newPort = {'port': 8084}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()

        chrome_options = webdriver.ChromeOptions()

#       user_agent = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.50 Safari/537.36'
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
#       chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)
        proxy.new_har('cartclog4', options={"captureContent":True, "captureHeaders":False})
        driver.get('http://10.10.30.247:9050/instument0.2/index.html')
        driver.maximize_window()
        time.sleep(7)
        driver.execute_script("console.log('robotlog');")
        driver.execute_script("console.info('robotinfo');")
        driver.execute_script("console.warn('robotwarn');")
        driver.execute_script("console.error('roboterror');")
        driver.execute_script("console.log('robotlog');")
        driver.execute_script("console.info('robotinfo');")
        driver.execute_script("console.warn('robotwarn');")
        driver.execute_script("console.error('roboterror');")
        time.sleep(7)
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        time.sleep(2)
        cartclog4Har = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/cartclog4.har", "w")
        f.write(cartclog4Har)
        f.close()
        driver.close()
        mobserver.stop()

#This should be last method that will kill the browsermobproxy
def check_kill_process(pstring):
    for line in os.popen("ps ax | grep " + pstring + " | grep -v grep"):
        fields = line.split()
        pid = fields[0]
        os.kill(int(pid), signal.SIGKILL)
#createsessionclog()
