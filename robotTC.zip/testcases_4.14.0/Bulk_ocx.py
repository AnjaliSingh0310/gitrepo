import selenium
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium import webdriver
from Selenium2Library import Selenium2Library
from browsermobproxy import Server
from pprint import pprint
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
import json
import time
import os, signal
import calendar
import socket

def get_free_tcp_port():
    tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    tcp.bind(('', 0))
    #addr, port = tcp.getsockname()
    port = tcp.getsockname()
    tcp.close()
    return port

def ajaxSessionmaster():
    MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
    '''p = get_free_tcp_port()
    newPort = {'port': p}'''
    newPort = {'port': 8082}
        #newPort = {'port': 25695}
    mobserver = Server(MOBPATH, options=newPort)
    mobserver.start()
    proxy = mobserver.create_proxy()
    chrome_options = webdriver.ChromeOptions()
    ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
    chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
    chrome_options.add_argument('--headless')
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--ignore-certificate-errors')
    chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
    capabilities = DesiredCapabilities.CHROME.copy()
    capabilities['acceptSslCerts'] = True
    capabilities['acceptInsecureCerts'] = True
    driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)

    proxy.new_har('cartAjax', options={"captureContent":True, "captureHeaders":True})
    driver.get('http://10.10.70.107:9001/app/cart.html')
    driver.maximize_window()
    time.sleep(5)
    btnDiv = driver.find_element_by_css_selector("#ajaxEvent")
    btnClick = driver.find_element_by_css_selector("button#ajaxEvent")
    actions = ActionChains(driver)
    actions.move_to_element(btnDiv)
    actions.click(btnClick)
    actions.perform()
    time.sleep(1)
    driver.execute_script("window.CAVNV.flush_all();")
    driver.execute_script("window.CAVNV.sbqueue.flush();")
    time.sleep(2)
    cartAjaxHar = json.dumps(proxy.har,ensure_ascii=False).encode('utf8')
    f = open("/home/cavisson/work/robotSuite/harfile/cartAjax.har", "wb")
    f.write(cartAjaxHar)
    f.close()
        #Code for js coverage Starts
    #/*driver.execute_script("window.open('http://10.10.30.247:9050/instument0.2/jscoverage.html', 'JSCoverInvertedMode')")
    #driver.switch_to.window(driver.window_handles[-1])
    #time.sleep(1)
    #jsonVal = driver.execute_script("return window.jscoverage_serializeCoverageToJSON()")
    #time.sleep(3)
    #jd = json.loads(jsonVal)
    #finalJson = json.dumps(jd)
    #f = open("/home/cavisson/work/robotSuite/jscoverFile/ajaxSession.json", "w")
    #f.write(finalJson)
    #f.close()
    #driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js14.png")
    #driver.switch_to.window(driver.window_handles[0])
        #Code for js coverage Ends

    driver.close()
    mobserver.stop()
def store():
    MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
    '''p = get_free_tcp_port()
    newPort = {'port': p}'''
    newPort = {'port': 8082}
        #newPort = {'port': 25695}
    mobserver = Server(MOBPATH, options=newPort)
    mobserver.start()
    proxy = mobserver.create_proxy()
    chrome_options = webdriver.ChromeOptions()
    ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
    chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
    chrome_options.add_argument('--headless')
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--ignore-certificate-errors')
    chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
    capabilities = DesiredCapabilities.CHROME.copy()
    capabilities['acceptSslCerts'] = True
    capabilities['acceptInsecureCerts'] = True
    driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)

    proxy.new_har('cartAjax', options={"captureContent":True, "captureHeaders":True})
    driver.get('http://10.10.30.247:9050/surya/cart.html')
    driver.maximize_window()
    time.sleep(5)
    btnDiv = driver.find_element_by_css_selector("#ajaxEvent")
    btnClick = driver.find_element_by_css_selector("button#ajaxEvent")
    actions = ActionChains(driver)
    actions.move_to_element(btnDiv)
    actions.click(btnClick)
    actions.perform()
    time.sleep(1)
    driver.execute_script("window.CAVNV.flush_all();")
    driver.execute_script("window.CAVNV.sbqueue.flush();")
    time.sleep(2)
    cartAjaxHar = json.dumps(proxy.har,ensure_ascii=False).encode('utf8')
    f = open("/home/cavisson/work/robotSuite/harfile/cartAjax.har", "wb")
    f.write(cartAjaxHar)
    f.close()
        #Code for js coverage Starts
    #/*driver.execute_script("window.open('http://10.10.30.247:9050/instument0.2/jscoverage.html', 'JSCoverInvertedMode')")
    #driver.switch_to.window(driver.window_handles[-1])
    #time.sleep(1)
    #jsonVal = driver.execute_script("return window.jscoverage_serializeCoverageToJSON()")
    #time.sleep(3)
    #jd = json.loads(jsonVal)
    #finalJson = json.dumps(jd)
    #f = open("/home/cavisson/work/robotSuite/jscoverFile/ajaxSession.json", "w")
    #f.write(finalJson)
    #f.close()
    #driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js14.png")
    #driver.switch_to.window(driver.window_handles[0])
        #Code for js coverage Ends

    driver.close()
    mobserver.stop()
def ajaxSessionslave():
    MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
    '''p = get_free_tcp_port()
    newPort = {'port': p}'''
    newPort = {'port': 8082}
        #newPort = {'port': 25695}
    mobserver = Server(MOBPATH, options=newPort)
    mobserver.start()
    proxy = mobserver.create_proxy()
    chrome_options = webdriver.ChromeOptions()
    ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
    chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
    chrome_options.add_argument('--headless')
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--ignore-certificate-errors')
    chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
    capabilities = DesiredCapabilities.CHROME.copy()
    capabilities['acceptSslCerts'] = True
    capabilities['acceptInsecureCerts'] = True
    driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)
    proxy.new_har('cartAjax', options={"captureContent":True, "captureHeaders":True})
    driver.get('http://10.10.70.163:9010/app/cart.html')
    driver.maximize_window()
    time.sleep(5)
    btnDiv = driver.find_element_by_css_selector("#ajaxEvent")
    btnClick = driver.find_element_by_css_selector("button#ajaxEvent")
    actions = ActionChains(driver)
    actions.move_to_element(btnDiv)
    actions.click(btnClick)
    actions.perform()
    time.sleep(1)
    driver.execute_script("window.CAVNV.flush_all();")
    driver.execute_script("window.CAVNV.sbqueue.flush();")
    time.sleep(2)
    cartAjaxHar = json.dumps(proxy.har,ensure_ascii=False).encode('utf8')
    f = open("/home/cavisson/work/robotSuite/harfile/cartAjax.har", "wb")
    f.write(cartAjaxHar)
    f.close()
        #Code for js coverage Starts
    #driver.execute_script("window.open('http://10.10.30.247:9050/instument0.2/jscoverage.html', 'JSCoverInvertedMode')")
    #driver.switch_to.window(driver.window_handles[-1])
    #time.sleep(1)
    #jsonVal = driver.execute_script("return window.jscoverage_serializeCoverageToJSON()")
    #time.sleep(3)
    #jd = json.loads(jsonVal)
    #finalJson = json.dumps(jd)
    #f = open("/home/cavisson/work/robotSuite/jscoverFile/ajaxSession.json", "w")
    #f.write(finalJson)
    #f.close()
    #driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js14.png")
    #driver.switch_to.window(driver.window_handles[0])
        #Code for js coverage Ends

    driver.close()
    mobserver.stop()
def createSessionmaster():
    MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
    '''p = get_free_tcp_port()
    newPort = {'port': p}'''

    newPort = {'port': 8082}
    #newPort = {'port': 25687}
    mobserver = Server(MOBPATH, options=newPort)
    mobserver.start()
    proxy = mobserver.create_proxy()

    chrome_options = webdriver.ChromeOptions()

#	user_agent = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.50 Safari/537.36'
    ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
    chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
    chrome_options.add_argument('--headless')
#	chrome_options.add_argument('--disable-gpu')
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument('--no-sandbox')
	#chrome_options.add_argument('--window-size=800,600')
	#chrome_options.add_argument("--user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36")

    chrome_options.add_argument('--ignore-certificate-errors')
    chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))

	# Disable Images
	#prefs = {
	#"profile.managed_default_content_settings.images":2
	#} 
	#chrome_options.add_experimental_option("prefs",prefs)

	# Tried with those stuff...
    capabilities = DesiredCapabilities.CHROME.copy()
    capabilities['acceptSslCerts'] = True
    capabilities['acceptInsecureCerts'] = True

	#driver = webdriver.Chrome(executable_path='/home/cavisson/work/robotSuite/chromedriver',chrome_options=chrome_options,desired_capabilities=capabilities)
    driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)
	#proxy.new_har('google', options={"captureContent":True, "captureBinaryContent":True})
    proxy.new_har('home', options={"captureContent":True, "captureBinaryContent":True,"captureHeaders":True})
	#proxy.new_har('homePage')
    try:
        driver.get('http://10.10.70.107:9001/app/cart.html')
        driver.maximize_window()
        action = ActionChains(driver);
    #print (driver.get_window_size())
        driver.set_window_size(1400, 900)
        wait = WebDriverWait(driver, 20) 
        sid=driver.execute_script("return window.CAVNV.sid;")
        driver.find_element(By.XPATH, '//a[text()="Home"]').click()
        driver.execute_script("window.scrollTo(0,document.body.scrollHeight);")
        time.sleep(2)
        element = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "csi")))
        menu = driver.find_element_by_css_selector("footer .container")
        hidden_submenu = driver.find_element_by_css_selector("footer .container button")
        actions = ActionChains(driver)
        actions.move_to_element(menu)
        actions.click(hidden_submenu)
        actions.perform()
        driver.find_element_by_id('csi').click();
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        time.sleep(5)
        print(sid)
	#pprint(proxy.har) # returns [] if using headless
        homeHar = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/home.har", "w")
        f.write(homeHar)
        f.close()


        #proxy.enableHarCaptureTypes(CaptureType.RESPONSE_HEADERS,CaptureType.RESPONSE_CONTENT);
        #proxy.whitelist('.*test_rum*', 200)
        proxy.new_har('homeCSI', options={"captureHeaders":True, "captureBinaryContent":True})
        proxy.new_har('homeCSI')
        driver.execute_script("window.scrollTo(0,document.body.scrollHeight);")
        time.sleep(2)
        element = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "csi")))
        driver.save_screenshot("homeCSI.png")
        menu = driver.find_element_by_css_selector("footer .container")
        hidden_submenu = driver.find_element_by_css_selector("footer .container button")
        actions = ActionChains(driver)
        actions.move_to_element(menu)
        actions.click(hidden_submenu)
        actions.perform()
        driver.find_element_by_id('csi').click();
        time.sleep(3)
        #driver.find_element(By.XPATH, '//a[text()="Home"]').click()
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        homeCSIHar = json.dumps(proxy.har)
        #f = open("/home/cavisson/work/robotSuite/harfile/HomePageCSI.har", "w")
        f = open("/home/cavisson/work/robotSuite/harfile/HomeCSI.har", "w")
        #f.write(homeCSIHar)
        f.write(homeCSIHar)
        f.close()
        driver.close()
    except Exception as e:
       print (e)
    finally:
       mobserver.stop()

def createSessionslave():
    MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
    '''p = get_free_tcp_port()
    newPort = {'port': p}'''

    newPort = {'port': 8082}
    #newPort = {'port': 25687}
    mobserver = Server(MOBPATH, options=newPort)
    mobserver.start()
    proxy = mobserver.create_proxy()

    chrome_options = webdriver.ChromeOptions()

#	user_agent = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.50 Safari/537.36'
    ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
    chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
    chrome_options.add_argument('--headless')
#	chrome_options.add_argument('--disable-gpu')
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument('--no-sandbox')
	#chrome_options.add_argument('--window-size=800,600')
	#chrome_options.add_argument("--user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36")

    chrome_options.add_argument('--ignore-certificate-errors')
    chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))

	# Disable Images
	#prefs = {
	#"profile.managed_default_content_settings.images":2
	#}
	#chrome_options.add_experimental_option("prefs",prefs)

	# Tried with those stuff...
    capabilities = DesiredCapabilities.CHROME.copy()
    capabilities['acceptSslCerts'] = True
    capabilities['acceptInsecureCerts'] = True

	#driver = webdriver.Chrome(executable_path='/home/cavisson/work/robotSuite/chromedriver',chrome_options=chrome_options,desired_capabilities=capabilities)
    driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)
	#proxy.new_har('google', options={"captureContent":True, "captureBinaryContent":True})
    proxy.new_har('home', options={"captureContent":True, "captureBinaryContent":True,"captureHeaders":True})
	#proxy.new_har('homePage')
    try:
        driver.get('http://10.10.70.163:9010/app/cart.html')
        driver.maximize_window()
        action = ActionChains(driver);
    #print (driver.get_window_size())
        driver.set_window_size(1400, 900)
        wait = WebDriverWait(driver, 20)
        sid=driver.execute_script("return window.CAVNV.sid;")
        driver.find_element(By.XPATH, '//a[text()="Home"]').click()
        driver.execute_script("window.scrollTo(0,document.body.scrollHeight);")
        time.sleep(2)
        element = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "csi")))
        menu = driver.find_element_by_css_selector("footer .container")
        hidden_submenu = driver.find_element_by_css_selector("footer .container button")
        actions = ActionChains(driver)
        actions.move_to_element(menu)
        actions.click(hidden_submenu)
        actions.perform()
        driver.find_element_by_id('csi').click();
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        time.sleep(5)
        print(sid)
	#pprint(proxy.har) # returns [] if using headless
        homeHar = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/home.har", "w")
        f.write(homeHar)
        f.close()


        #proxy.enableHarCaptureTypes(CaptureType.RESPONSE_HEADERS,CaptureType.RESPONSE_CONTENT);
        #proxy.whitelist('.*test_rum*', 200)
        proxy.new_har('homeCSI', options={"captureHeaders":True, "captureBinaryContent":True})
        proxy.new_har('homeCSI')
        driver.execute_script("window.scrollTo(0,document.body.scrollHeight);")
        time.sleep(2)
        element = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "csi")))
        driver.save_screenshot("homeCSI.png")
        menu = driver.find_element_by_css_selector("footer .container")
        hidden_submenu = driver.find_element_by_css_selector("footer .container button")
        actions = ActionChains(driver)
        actions.move_to_element(menu)
        actions.click(hidden_submenu)
        actions.perform()
        driver.find_element_by_id('csi').click();
        time.sleep(3)
        #driver.find_element(By.XPATH, '//a[text()="Home"]').click()
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        homeCSIHar = json.dumps(proxy.har)
        #f = open("/home/cavisson/work/robotSuite/harfile/HomePageCSI.har", "w")
        f = open("/home/cavisson/work/robotSuite/harfile/HomeCSI.har", "w")
        #f.write(homeCSIHar)
        f.write(homeCSIHar)
        f.close()
        driver.close()
    except Exception as e:
       print (e)
    finally:
       mobserver.stop()
#ajaxSessionmaster()
#ajaxSessionslave()
#store()
