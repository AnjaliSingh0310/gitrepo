from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium import webdriver
from Selenium2Library import Selenium2Library
from browsermobproxy import Server
from pprint import pprint
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import json
import time
import os, signal

import socket

def get_free_tcp_port():
    tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    tcp.bind(('', 0))
    addr, port = tcp.getsockname()
    tcp.close()
    return port

def abtSession():
        variationData = []
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        p = get_free_tcp_port()
        newPort = {'port': p}
        #newPort = {'port': 8082}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()
        chrome_options = webdriver.ChromeOptions()
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)

        proxy.new_har('cartAjax', options={"captureContent":True, "captureHeaders":True})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/checkout.html')
        time.sleep(5)
        driver.execute_script("window.scrollBy(0,500)")
        wait = WebDriverWait(driver, 10)
        element = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, '[name="fname"]')))
        driver.find_element_by_css_selector("[name='fname']").click()
        addedVariationCount = driver.execute_script("return JSON.parse(localStorage.getItem('nvabv')).added.length")
        addedVariation = driver.execute_script("return JSON.parse(localStorage.getItem('nvabv')).added")
        completedVariationCount = driver.execute_script("return JSON.parse(localStorage.getItem('nvabv')).completed.length")
        completedVariation = driver.execute_script("return JSON.parse(localStorage.getItem('nvabv')).completed")

        cartAjaxHar = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/abtesting.har", "w")
        f.write(cartAjaxHar)
        f.close()
        #Code for js coverage Starts
        driver.execute_script("window.open('https://nvrobot.cav-test.com/instument0.2/swapp/jscoverage.html', 'JSCoverInvertedMode')")
        driver.switch_to.window(driver.window_handles[-1])
        time.sleep(1)
        jsonVal = driver.execute_script("return window.jscoverage_serializeCoverageToJSON()")
        time.sleep(3)
        jd = json.loads(jsonVal)
        finalJson = json.dumps(jd)
        f = open("/home/cavisson/work/robotSuite/swjscoverFile/abtesting.json", "w")
        f.write(finalJson)
        f.close()
        driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js26.png")
        #Code for js coverage Ends      
        driver.close()
        mobserver.stop()
        variationData.append(addedVariationCount)
        variationData.append(addedVariation)
        variationData.append(completedVariationCount)
        variationData.append(completedVariation)
        return variationData

#abtSession()

def createSession():
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        #p = get_free_tcp_port()
        #newPort = {'port': p}

        newPort = {'port': 8089}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()

        chrome_options = webdriver.ChromeOptions()

#        user_agent = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.50 Safari/537.36'
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
#        chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        #chrome_options.add_argument('--window-size=800,600')
        #chrome_options.add_argument("--user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36")

        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))

        # Disable Images
        #prefs = {
        #"profile.managed_default_content_settings.images":2
        #} 
        #chrome_options.add_experimental_option("prefs",prefs)

        # Tried with those stuff...
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True

        #driver = webdriver.Chrome(executable_path='/home/cavisson/work/robotSuite/chromedriver',chrome_options=chrome_options,desired_capabilities=capabilities)
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)
        #proxy.new_har('google', options={"captureContent":True, "captureBinaryContent":True})
        proxy.new_har('home', options={"captureContent":False, "captureBinaryContent":False})
        #proxy.new_har('homePage')
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/index.html')
        driver.maximize_window()
        print (driver.get_window_size())
        time.sleep(2) 
        sid=driver.execute_script("return window.CAVNV.sid;")
        print(sid)
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        time.sleep(5)
        #pprint(proxy.har) # returns [] if using headless
        homeHar = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/HomePage.har", "w")
        f.write(homeHar)
        f.close()


#        proxy.enableHarCaptureTypes(CaptureType.RESPONSE_HEADERS,CaptureType.RESPONSE_CONTENT);
        #proxy.whitelist('.*test_rum*', 200)
        proxy.new_har('homeCSI', options={"captureContent":True, "captureHeaders":True})
        #proxy.new_har('homeCSI')
        #driver.execute_script("window.scrollTo(0,document.body.scrollHeight);")
        time.sleep(2)
#        element = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "csi")))
        driver.save_screenshot("homeCSI.png")
        menu = driver.find_element_by_css_selector("footer .container")
        hidden_submenu = driver.find_element_by_css_selector("footer .container button")
        actions = ActionChains(driver)
        actions.move_to_element(menu)
        actions.click(hidden_submenu)
        actions.perform()
#        driver.find_element_by_id('csi').click();
        time.sleep(3)
        driver.execute_script('var xhttp = new XMLHttpRequest();xhttp.onreadystatechange = function() {console.log("xhr fired")};xhttp.open("GET", "https://10.20.0.65:8003/tours/nv.js", true);xhttp.send();')
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        homeCSIHar = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/HomePageCSI.har", "w")
        f.write(homeCSIHar)
        f.close()
        #Code for js coverage Starts
        driver.execute_script("window.open('https://nvrobot.cav-test.com/instument0.2/swapp/jscoverage.html', 'JSCoverInvertedMode')")
        driver.switch_to.window(driver.window_handles[-1])
        time.sleep(1)
        jsonVal = driver.execute_script("return jscoverage_serializeCoverageToJSON();")
        time.sleep(3)
        jd = json.loads(jsonVal)
        finalJson = json.dumps(jd)
        f = open("/home/cavisson/work/robotSuite/swjscoverFile/createSession2.json", "w")
        f.write(finalJson)
        f.close()
        driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js2.png")
        driver.switch_to.window(driver.window_handles[0])
        #Code for js coverage Ends      

        driver.find_element_by_css_selector('.oi.oi-menu').click()
        time.sleep(1)
        driver.find_element_by_css_selector('[href="cart.html"].nav-link').click()
        #driver.implicitly_wait(10)        
        time.sleep(5)
        proxy.new_har('cartPage', options={"captureContent":False, "captureBinaryContent":False})  
        #chkBtn = WebDriverWait(driver, 20).until(EC.element_to_be_clickable((By.CSS_SELECTOR, "[href='checkout.html'].btn")));
        driver.execute_script("window.scrollBy(0,1000)");
        driver.save_screenshot("cart.png") 
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        time.sleep(1)
        cartHar = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/CartPage.har","w")
        f.write(cartHar)
        f.close()

        #Code for js coverage Starts
        driver.execute_script("window.open('https://nvrobot.cav-test.com/instument0.2/swapp/jscoverage.html', 'JSCoverInvertedMode')")
        driver.switch_to.window(driver.window_handles[-1])
        time.sleep(1)
        jsonVal = driver.execute_script("return jscoverage_serializeCoverageToJSON();")
        time.sleep(3)
        jd = json.loads(jsonVal)
        finalJson = json.dumps(jd)
        f = open("/home/cavisson/work/robotSuite/swjscoverFile/createSession3.json", "w")
        f.write(finalJson)
        f.close()
        driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js3.png")
        driver.switch_to.window(driver.window_handles[0])
        #Code for js coverage Ends      
       
        proxy.new_har('homeWithPostData', options={"captureContent":True, "captureHeaders": True})
        #proxy.new_har('homePage')
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/index.html')
        driver.maximize_window()
        time.sleep(5) 
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        time.sleep(1)
        #pprint(proxy.har) # returns [] if using headless
        homeWithPostDataHar = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/HomePageWithPostData.har", "w")
        f.write(homeWithPostDataHar)
        f.close()
        #Code for js coverage Starts
        driver.execute_script("window.open('https://nvrobot.cav-test.com/instument0.2/swapp/jscoverage.html', 'JSCoverInvertedMode')")
        driver.switch_to.window(driver.window_handles[-1])
        time.sleep(1)
        jsonVal = driver.execute_script("return jscoverage_serializeCoverageToJSON();")
        time.sleep(3)
        jd = json.loads(jsonVal)
        finalJson = json.dumps(jd)
        f = open("/home/cavisson/work/robotSuite/swjscoverFile/createSession3.json", "w")
        f.write(finalJson)
        f.close()
        driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js3.png")
        driver.switch_to.window(driver.window_handles[0])
        #Code for js coverage Ends      

        driver.close()
        mobserver.stop()


def uaSession():
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        p = get_free_tcp_port()
        newPort = {'port': p}

        #newPort = {'port': 8082}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()
        chrome_options = webdriver.ChromeOptions()
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)

        proxy.new_har('homeUA', options={"captureContent":True, "captureHeaders":False})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/index.html')
        driver.maximize_window()
        time.sleep(5) 
        menu = driver.find_element_by_css_selector("footer .container")
        hidden_submenu = driver.find_element_by_css_selector("footer .container button")
        actions = ActionChains(driver)
        actions.move_to_element(menu)
        actions.click(hidden_submenu)
        actions.perform()
        time.sleep(6) 
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        time.sleep(1)
        driver.find_element_by_css_selector('.oi.oi-menu').click()
        time.sleep(1)
        driver.execute_script('window.document.documentElement.scrollTop = 0;')
        driver.find_element_by_id('dropdown04').click()
        time.sleep(1)
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        time.sleep(2)
        #pprint(proxy.har) # returns [] if using headless
        homeUAHar = json.dumps(proxy.har,ensure_ascii=False).encode('utf8')
        f = open("/home/cavisson/work/robotSuite/harfile/HomeUA.har", "w")
        f.write(homeUAHar)
        f.close()

        #Code for js coverage Starts
        driver.execute_script("window.open('https://nvrobot.cav-test.com/instument0.2/swapp/jscoverage.html', 'JSCoverInvertedMode')")
        driver.switch_to.window(driver.window_handles[-1])
        time.sleep(1)
        jsonVal = driver.execute_script("return window.jscoverage_serializeCoverageToJSON()")
        time.sleep(3)
        jd = json.loads(jsonVal)
        finalJson = json.dumps(jd)
        f = open("/home/cavisson/work/robotSuite/swjscoverFile/uaSession.json", "w")
        f.write(finalJson)
        f.close()
        driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js4.png")
        driver.switch_to.window(driver.window_handles[0])
        #Code for js coverage Ends     

        driver.close()
        mobserver.stop()

def cmSession():
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        p = get_free_tcp_port()
        newPort = {'port': p}
        #newPort = {'port': 8082}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()
        chrome_options = webdriver.ChromeOptions()
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)

        proxy.new_har('cartCM', options={"captureContent":True, "captureHeaders":False})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/cart.html')
        driver.maximize_window()
        time.sleep(1) 
        driver.execute_script("(function (){var t=document.querySelectorAll(\".product-name h3\").length,e={},o=[],c={name:document.querySelectorAll(\".product-name h3\")[0].textContent,qty:document.querySelectorAll('[name=\"quantity\"]')[0].value};o.push(c);c={name:document.querySelectorAll(\".product-name h3\")[1].textContent,qty:document.querySelectorAll('[name=\"quantity\"]')[1].value};o.push(c),e.prod=o;var n=document.querySelector(\".total-price\").textContent.trim().replace(/[^0-9.]/g,\"\"),u=document.querySelector(\"h1\").textContent;cav_nv_log_customMetrics(\"RobotCMNumber\",t),cav_nv_log_customMetrics(\"RobotCMtext\",u),cav_nv_log_customMetrics(\"RobotCMDouble\",n),cav_nv_log_customMetrics(\"RobotCMJson\",e)})();")
        time.sleep(5)
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        cartCMHar = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/cartCM.har", "w")
        f.write(cartCMHar)
        f.close()

        #Code for js coverage Starts
        driver.execute_script("window.open('https://nvrobot.cav-test.com/instument0.2/swapp/jscoverage.html', 'JSCoverInvertedMode')")
        driver.switch_to.window(driver.window_handles[-1])
        time.sleep(1)
        jsonVal = driver.execute_script("return window.jscoverage_serializeCoverageToJSON()")
        time.sleep(3)
        jd = json.loads(jsonVal)
        finalJson = json.dumps(jd)
        f = open("/home/cavisson/work/robotSuite/swjscoverFile/cmSession.json", "w")
        f.write(finalJson)
        f.close()
        driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js5.png")
        driver.switch_to.window(driver.window_handles[0])
        #Code for js coverage Ends      

        driver.close()
        mobserver.stop()

def rtSession():
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        p = get_free_tcp_port()
        newPort = {'port': p}
        #newPort = {'port': 8082}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()
        chrome_options = webdriver.ChromeOptions()
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)

        proxy.new_har('cartResource', options={"captureContent":True, "captureHeaders":False})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/cart.html')
        driver.maximize_window()
        time.sleep(5) 
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        cartRTHar = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/cartRT.har", "w")
        f.write(cartRTHar)
        f.close()

        #Code for js coverage Starts
        driver.execute_script("window.open('https://nvrobot.cav-test.com/instument0.2/swapp/jscoverage.html', 'JSCoverInvertedMode')")
        driver.switch_to.window(driver.window_handles[-1])
        time.sleep(1)
        jsonVal = driver.execute_script("return window.jscoverage_serializeCoverageToJSON()")
        time.sleep(3)
        jd = json.loads(jsonVal)
        finalJson = json.dumps(jd)
        f = open("/home/cavisson/work/robotSuite/swjscoverFile/rtSession.json", "w")
        f.write(finalJson)
        f.close()
        driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js6.png")
        driver.switch_to.window(driver.window_handles[0])
        #Code for js coverage Ends      

        driver.close()
        mobserver.stop()

#uaSession()
def fbSession():
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        p = get_free_tcp_port()
        newPort = {'port': p}
        #newPort = {'port': 8082}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()

        chrome_options = webdriver.ChromeOptions()

#        user_agent = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.50 Safari/537.36'
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
#        chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        #chrome_options.add_argument('--window-size=800,600')
        #chrome_options.add_argument("--user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36")

        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))

        # Disable Images
        #prefs = {
        #"profile.managed_default_content_settings.images":2
        #} 
        #chrome_options.add_experimental_option("prefs",prefs)

        # Tried with those stuff...
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True

        #driver = webdriver.Chrome(executable_path='/home/cavisson/work/robotSuite/chromedriver',chrome_options=chrome_options,desired_capabilities=capabilities)
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)
        #proxy.new_har('google', options={"captureContent":True, "captureBinaryContent":True})
        proxy.new_har('Feedback', options={"captureContent":True, "captureHeaders":True})
        #proxy.new_har('homePage')
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/cart.html')
        driver.maximize_window()
        print (driver.get_window_size())
        time.sleep(5) 
        driver.execute_script("window.scrollTo(0,document.body.scrollHeight);")
        driver.find_element_by_id("SendFeedback").click()
        driver.save_screenshot("feedbackScreentshot.png")
        driver.find_element_by_id("nvname").send_keys("Robot")        
        driver.find_element_by_id("nvemail").send_keys("automation@cavisson.com")        
        driver.find_element_by_id("nvtelephone").send_keys("9876543210")        
        driver.find_element_by_id("nvareaid").send_keys("Custom Message")        
        driver.save_screenshot("feedbackScreentshotAfterData.png")
        driver.execute_script("window.document.querySelectorAll('.nvfeedback-btn')[1].click();")
        driver.save_screenshot("feedbackScreentshotREview.png")
        driver.execute_script("window.document.querySelectorAll('.nvfeedback-btn')[2].click();")
        driver.save_screenshot("feedbackScreentshotREviewFianl.png")
        driver.execute_script("window.document.querySelectorAll('.nvfeedback-btn')[1].click();")
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        time.sleep(1)
        #pprint(proxy.har) # returns [] if using headless
        fbHar = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/Feedback.har", "w")
        f.write(fbHar)
        f.close()

        #Code for js coverage Starts
        driver.execute_script("window.open('https://nvrobot.cav-test.com/instument0.2/swapp/jscoverage.html', 'JSCoverInvertedMode')")
        driver.switch_to.window(driver.window_handles[-1])
        time.sleep(1)
        jsonVal = driver.execute_script("return window.jscoverage_serializeCoverageToJSON()")
        time.sleep(3)
        jd = json.loads(jsonVal)
        finalJson = json.dumps(jd)
        f = open("/home/cavisson/work/robotSuite/swjscoverFile/fbSession.json", "w")
        f.write(finalJson)
        f.close()
        driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js7.png")
        driver.switch_to.window(driver.window_handles[0])
        #Code for js coverage Ends      

        driver.close()
        mobserver.stop()

def eventSession():
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        p = get_free_tcp_port()
        newPort = {'port': p}
        #newPort = {'port': 8082}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()
        chrome_options = webdriver.ChromeOptions()
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)
        proxy.new_har('homeEL', options={"captureContent":True, "captureHeaders":False})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/index.html')
        driver.maximize_window()
        time.sleep(5) 
        driver.execute_script("window.cav_nv_log_event('RobotEvent',{})")
        driver.execute_script("window.cav_nv_log_event('RobotEvent',{'msg':'Robot Event With Message'})")
        ot = "10"
        driver.execute_script("window.cav_nv_set_orderTotal("+ot+")")
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        time.sleep(1)
        #pprint(proxy.har) # returns [] if using headless
        homeELHar = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/HomeEL.har", "w")
        f.write(homeELHar)
        f.close()

        #Code for js coverage Starts
        driver.execute_script("window.open('https://nvrobot.cav-test.com/instument0.2/swapp/jscoverage.html', 'JSCoverInvertedMode')")
        driver.switch_to.window(driver.window_handles[-1])
        time.sleep(1)
        jsonVal = driver.execute_script("return window.jscoverage_serializeCoverageToJSON()")
        time.sleep(3)
        jd = json.loads(jsonVal)
        finalJson = json.dumps(jd)
        f = open("/home/cavisson/work/robotSuite/swjscoverFile/eventSession.json", "w")
        f.write(finalJson)
        f.close()
        driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js8.png")
        driver.switch_to.window(driver.window_handles[0])
        #Code for js coverage Ends      

        driver.close()
        mobserver.stop()

#eventSession()

def parseHarData(harName,requestName,*args):
        harName =  "/home/cavisson/work/robotSuite/harfile/"+harName+".har"
        #harName =  "/home/cavisson/work/robotSuite/harfile/HomePageCSI.har"
        print (harName)
        # Opening JSON file 
        f = open(harName,)
        data = json.load(f)
        f.close()
        entryList= data["log"]["entries"];
        print (len(entryList))
        hData = [];
        for entry in entryList:
            urlVal = entry["request"]["url"]
            if requestName in urlVal:
                 print (urlVal)
                 if len(args) == 0:
                         rStatus = entry["response"]["status"]
                         d = [urlVal,rStatus]
                         hData.append(d)
                 else:
                         searchParameter = args[0]
                         rParam = entry["request"][searchParameter]
                         print(rParam)
                         d = [urlVal,rParam]
                         hData.append(d)
        return hData
        #print (hData)
#parseHarData("Home","op=domwatcher","headers")

def parseHarDataWithData(harName,requestName,*args):
        harName =  "/home/cavisson/work/robotSuite/harfile/"+harName+".har"
        #harName =  "/home/cavisson/work/robotSuite/harfile/HomePageWithPostData.har"
        print (harName)
        sp = len(args)        
        # Opening JSON file 
        f = open(harName,)
        data = json.load(f)
        f.close()
        entryList= data["log"]["entries"];
        print (len(entryList))
        hData = [];
        for entry in entryList:
            urlVal = entry["request"]["url"]
            if requestName in urlVal:
                 #print (urlVal)
                 rStatus = entry["request"]["postData"]["text"]
                 if sp > 0:
                        print("in if")
                        searchPattern = args[0]
                        if searchPattern in rStatus:
                                 d = [urlVal,rStatus]
                                 hData.append(d)
                 else:
                    print("in else")
                    d = [urlVal,rStatus]
                    hData.append(d)

        return hData
        #print hData

#parseHarDataWithData("Feedback","op=feedback")
#parseHarDataWithData("HomeUA","op=useraction")
def checkpointSession():
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        p = get_free_tcp_port()
        newPort = {'port': p}
        #newPort = {'port': 8082}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()
        chrome_options = webdriver.ChromeOptions()
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)

        proxy.new_har('cartCP', options={"captureContent":True, "captureHeaders":False})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/cart.html')
        driver.maximize_window()
        time.sleep(5) 
        btnDiv = driver.find_element_by_css_selector("#dwEvent")
        btnClick = driver.find_element_by_css_selector("button#dwEvent")
        actions = ActionChains(driver)
        actions.move_to_element(btnDiv)
        actions.click(btnClick)
        actions.perform()
        time.sleep(1)
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        time.sleep(2)
        cartCPHar = json.dumps(proxy.har,ensure_ascii=False).encode('utf8')
        f = open("/home/cavisson/work/robotSuite/harfile/cartCP.har", "w")
        f.write(cartCPHar)
        f.close()

        #Code for js coverage Starts
        driver.execute_script("window.open('https://nvrobot.cav-test.com/instument0.2/swapp/jscoverage.html', 'JSCoverInvertedMode')")
        driver.switch_to.window(driver.window_handles[-1])
        time.sleep(1)
        jsonVal = driver.execute_script("return window.jscoverage_serializeCoverageToJSON()")
        time.sleep(3)
        jd = json.loads(jsonVal)
        finalJson = json.dumps(jd)
        f = open("/home/cavisson/work/robotSuite/swjscoverFile/checkpointSession.json", "w")
        f.write(finalJson)
        f.close()
        driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js9.png")
        driver.switch_to.window(driver.window_handles[0])
        #Code for js coverage Ends      

        driver.close()
        mobserver.stop()

def ocxFilterSession():
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        p = get_free_tcp_port()
        newPort = {'port': p}
        #newPort = {'port': 8082}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()
        chrome_options = webdriver.ChromeOptions()
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)

        proxy.new_har('homeOCXF', options={"captureContent":True, "captureHeaders":True})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/index.html')
        driver.maximize_window()
        time.sleep(5) 
        menu = driver.find_element_by_css_selector("footer .container")
        hidden_submenu = driver.find_element_by_css_selector("footer .container button")
        actions = ActionChains(driver)
        actions.move_to_element(menu)
        actions.click(hidden_submenu)
        actions.perform()
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        homeocxPage = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/homeocxPage.har", "w")
        f.write(homeocxPage)
        f.close()
        proxy.new_har('cartocxFilter', options={"captureContent":True, "captureHeaders":True})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/index.html')
        driver.maximize_window()
        time.sleep(1) 
        time.sleep(1)
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        time.sleep(2)
        cartocxFilter= json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/cartOCXFilter.har", "w")
        f.write(cartocxFilter)
        f.close()

        #Code for js coverage Starts
        driver.execute_script("window.open('https://nvrobot.cav-test.com/instument0.2/swapp/jscoverage.html', 'JSCoverInvertedMode')")
        driver.switch_to.window(driver.window_handles[-1])
        time.sleep(1)
        jsonVal = driver.execute_script("return window.jscoverage_serializeCoverageToJSON()")
        time.sleep(3)
        jd = json.loads(jsonVal)
        finalJson = json.dumps(jd)
        f = open("/home/cavisson/work/robotSuite/swjscoverFile/ocxFilterSession1.json", "w")
        f.write(finalJson)
        f.close()
        driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js10.png")
        driver.switch_to.window(driver.window_handles[0])
        #Code for js coverage Ends      

        proxy.new_har('checkoutOCXF', options={"captureContent":True, "captureHeaders":True})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/index.html')
        driver.maximize_window()
        time.sleep(5) 
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        homeocxPage = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/checkoutocxPage.har", "w")
        f.write(homeocxPage)
        f.close()

        #Code for js coverage Starts
        driver.execute_script("window.open('https://nvrobot.cav-test.com/instument0.2/swapp/jscoverage.html', 'JSCoverInvertedMode')")
        driver.switch_to.window(driver.window_handles[-1])
        time.sleep(1)
        jsonVal = driver.execute_script("return window.jscoverage_serializeCoverageToJSON()")
        time.sleep(3)
        jd = json.loads(jsonVal)
        finalJson = json.dumps(jd)
        f = open("/home/cavisson/work/robotSuite/swjscoverFile/ocxFilterSession2.json", "w")
        f.write(finalJson)
        f.close()
        driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js11.png")
        driver.switch_to.window(driver.window_handles[0])
        #Code for js coverage Ends      

        driver.close()
        mobserver.stop()

def ocxByuerStateSession():
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        p = get_free_tcp_port()
        newPort = {'port': p}
        #newPort = {'port': 8082}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()
        chrome_options = webdriver.ChromeOptions()
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)

        proxy.new_har('checkoutOCXF', options={"captureContent":True, "captureHeaders":True})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/index.html')
        driver.maximize_window()
        time.sleep(5) 
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        checkoutocxPage = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/buyerOCXHome.har", "w")
        f.write(checkoutocxPage)
        f.close()

        #Code for js coverage Starts
        driver.execute_script("window.open('https://nvrobot.cav-test.com/instument0.2/swapp/jscoverage.html', 'JSCoverInvertedMode')")
        driver.switch_to.window(driver.window_handles[-1])
        time.sleep(1)
        jsonVal = driver.execute_script("return window.jscoverage_serializeCoverageToJSON()")
        time.sleep(3)
        jd = json.loads(jsonVal)
        finalJson = json.dumps(jd)
        f = open("/home/cavisson/work/robotSuite/swjscoverFile/ocxByuerStateSession1.json", "w")
        f.write(finalJson)
        f.close()
        driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js12.png")
        driver.switch_to.window(driver.window_handles[0])
        #Code for js coverage Ends      

        proxy.new_har('shopOCXF', options={"captureContent":True, "captureHeaders":True})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/shop.html')
        driver.maximize_window()
        time.sleep(5) 
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        checkoutocxPage = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/buyerOCXShop.har", "w")
        f.write(checkoutocxPage)
        f.close()

        #Code for js coverage Starts
        driver.execute_script("window.open('https://nvrobot.cav-test.com/instument0.2/swapp/jscoverage.html', 'JSCoverInvertedMode')")
        driver.switch_to.window(driver.window_handles[-1])
        time.sleep(1)
        jsonVal = driver.execute_script("return window.jscoverage_serializeCoverageToJSON()")
        time.sleep(3)
        jd = json.loads(jsonVal)
        finalJson = json.dumps(jd)
        f = open("/home/cavisson/work/robotSuite/swjscoverFile/ocxByuerStateSession2.json", "w")
        f.write(finalJson)
        f.close()
        driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js13.png")
        driver.switch_to.window(driver.window_handles[0])
        #Code for js coverage Ends      

        driver.close()
        mobserver.stop()

def ajaxSession():
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        p = get_free_tcp_port()
        newPort = {'port': p}
        #newPort = {'port': 8082}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()
        chrome_options = webdriver.ChromeOptions()
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)

        proxy.new_har('cartAjax', options={"captureContent":True, "captureHeaders":True})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/cart.html')
        driver.maximize_window()
        time.sleep(5) 
        btnDiv = driver.find_element_by_css_selector("#ajaxEvent")
        btnClick = driver.find_element_by_css_selector("button#ajaxEvent")
        actions = ActionChains(driver)
        actions.move_to_element(btnDiv)
        actions.click(btnClick)
        actions.perform()
        time.sleep(1)
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        time.sleep(2)
        cartAjaxHar = json.dumps(proxy.har,ensure_ascii=False).encode('utf8')
        f = open("/home/cavisson/work/robotSuite/harfile/cartAjax.har", "w")
        f.write(cartAjaxHar)
        f.close()
        #Code for js coverage Starts
        driver.execute_script("window.open('https://nvrobot.cav-test.com/instument0.2/swapp/jscoverage.html', 'JSCoverInvertedMode')")
        driver.switch_to.window(driver.window_handles[-1])
        time.sleep(1)
        jsonVal = driver.execute_script("return window.jscoverage_serializeCoverageToJSON()")
        time.sleep(3)
        jd = json.loads(jsonVal)
        finalJson = json.dumps(jd)
        f = open("/home/cavisson/work/robotSuite/swjscoverFile/ajaxSession.json", "w")
        f.write(finalJson)
        f.close()
        driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js14.png")
        driver.switch_to.window(driver.window_handles[0])
        #Code for js coverage Ends      

        driver.close()
        mobserver.stop()

def createsessionRT():
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        p = get_free_tcp_port()
        newPort = {'port': p}
        #newPort = {'port': 8082}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()

        chrome_options = webdriver.ChromeOptions()

#        user_agent = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.50 Safari/537.36'
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
#        chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        #chrome_options.add_argument('--window-size=800,600')
        #chrome_options.add_argument("--user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36")

        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))

        # Disable Images
        #prefs = {
        #"profile.managed_default_content_settings.images":2
        #} 
        #chrome_options.add_experimental_option("prefs",prefs)

        # Tried with those stuff...
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True

        #driver = webdriver.Chrome(executable_path='/home/cavisson/work/robotSuite/chromedriver',chrome_options=chrome_options,desired_capabilities=capabilities)
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)
        #proxy.new_har('google', options={"captureContent":True, "captureBinaryContent":True})
        proxy.new_har('homeRT', options={"captureContent":True, "captureHeaders":False})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/cart.html')
        driver.maximize_window()
        time.sleep(5) 
        btnDiv = driver.find_element_by_css_selector("#dwEvent")
        btnClick = driver.find_element_by_css_selector("button#dwEvent")
        actions = ActionChains(driver)
        actions.move_to_element(btnDiv)
        actions.click(btnClick)
        actions.perform()
        time.sleep(1)
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        time.sleep(2)
        homeRTHar = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/homeRT.har", "w")
        f.write(homeRTHar)
        f.close()

        #Code for js coverage Starts
        driver.execute_script("window.open('https://nvrobot.cav-test.com/instument0.2/swapp/jscoverage.html', 'JSCoverInvertedMode')")
        driver.switch_to.window(driver.window_handles[-1])
        time.sleep(1)
        jsonVal = driver.execute_script("return window.jscoverage_serializeCoverageToJSON()")
        time.sleep(3)
        jd = json.loads(jsonVal)
        finalJson = json.dumps(jd)
        f = open("/home/cavisson/work/robotSuite/swjscoverFile/createsessionRT1.json", "w")
        f.write(finalJson)
        f.close()
        driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js15.png")
        driver.switch_to.window(driver.window_handles[0])
        #Code for js coverage Ends      

        proxy.new_har('cartRT2', options={"captureContent":True, "captureHeaders": True})
        #proxy.new_har('homePage')
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/cart.html')
        driver.maximize_window()
        time.sleep(5) 
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        time.sleep(1)
        #pprint(proxy.har) # returns [] if using headless
        cartRT2Har = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/cartRT2.har", "w")
        f.write(cartRT2Har)
        f.close()

        #Code for js coverage Starts
        driver.execute_script("window.open('https://nvrobot.cav-test.com/instument0.2/swapp/jscoverage.html', 'JSCoverInvertedMode')")
        driver.switch_to.window(driver.window_handles[-1])
        time.sleep(1)
        jsonVal = driver.execute_script("return window.jscoverage_serializeCoverageToJSON()")
        time.sleep(3)
        jd = json.loads(jsonVal)
        finalJson = json.dumps(jd)
        f = open("/home/cavisson/work/robotSuite/swjscoverFile/createsessionRT2.json", "w")
        f.write(finalJson)
        f.close()
        driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js16.png")
        driver.switch_to.window(driver.window_handles[0])
        #Code for js coverage Ends      

        proxy.new_har('checkoutRT', options={"captureContent":True, "captureHeaders":False})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/checkout.html')
        driver.maximize_window()
        time.sleep(10) 
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        checkoutRTHar = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/checkoutRT.har", "w")
        f.write(checkoutRTHar)
        f.close()

        #Code for js coverage Starts
        driver.execute_script("window.open('https://nvrobot.cav-test.com/instument0.2/swapp/jscoverage.html', 'JSCoverInvertedMode')")
        driver.switch_to.window(driver.window_handles[-1])
        time.sleep(1)
        jsonVal = driver.execute_script("return window.jscoverage_serializeCoverageToJSON()")
        time.sleep(3)
        jd = json.loads(jsonVal)
        finalJson = json.dumps(jd)
        f = open("/home/cavisson/work/robotSuite/swjscoverFile/createsessionRT3.json", "w")
        f.write(finalJson)
        f.close()
        driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js17.png")
        driver.switch_to.window(driver.window_handles[0])
        #Code for js coverage Ends      

        driver.close()
        mobserver.stop()

def createsessionJS():
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        p = get_free_tcp_port()
        newPort = {'port': p}
        #newPort = {'port': 8082}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()

        chrome_options = webdriver.ChromeOptions()

#        user_agent = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.50 Safari/537.36'
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
#        chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        #chrome_options.add_argument('--window-size=800,600')
        #chrome_options.add_argument("--user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36")

        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))

        # Disable Images
        #prefs = {
        #"profile.managed_default_content_settings.images":2
        #} 
        #chrome_options.add_experimental_option("prefs",prefs)

        # Tried with those stuff...
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True

        #driver = webdriver.Chrome(executable_path='/home/cavisson/work/robotSuite/chromedriver',chrome_options=chrome_options,desired_capabilities=capabilities)
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)
        #proxy.new_har('google', options={"captureContent":True, "captureBinaryContent":True})
        proxy.new_har('homeRT', options={"captureContent":True, "captureHeaders":False})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/cart.html')
        driver.maximize_window()
        time.sleep(5) 
        jseDiv = driver.find_element_by_id("jse")
        jseBtn = driver.find_element_by_id("jse")
        actions = ActionChains(driver)
        actions.move_to_element(jseDiv)
        actions.click(jseBtn)
        actions.perform()
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        homeRTHar = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/cartJS.har", "w")
        f.write(homeRTHar)
        f.close()
        #Code for js coverage Starts
        driver.execute_script("window.open('https://nvrobot.cav-test.com/instument0.2/swapp/jscoverage.html', 'JSCoverInvertedMode')")
        driver.switch_to.window(driver.window_handles[-1])
        time.sleep(1)
        jsonVal = driver.execute_script("return window.jscoverage_serializeCoverageToJSON()")
        time.sleep(3)
        jd = json.loads(jsonVal)
        finalJson = json.dumps(jd)
        f = open("/home/cavisson/work/robotSuite/swjscoverFile/createsessionJSError.json", "w")
        f.write(finalJson)
        f.close()
        driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js18.png")
        driver.switch_to.window(driver.window_handles[0])
        #Code for js coverage Ends      

        proxy.new_har('homeRT', options={"captureContent":True, "captureHeaders":False})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/cart.html')
        btnDiv = driver.find_element_by_css_selector("#dwEvent")
        btnClick = driver.find_element_by_css_selector("button#dwEvent")
        actions = ActionChains(driver)
        actions.move_to_element(btnDiv)
        actions.click(btnClick)
        actions.perform()
        
        time.sleep(1)
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        time.sleep(2)
        homeRTHar = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/homeRT.har", "w")
        f.write(homeRTHar)
        f.close()
        #Code for js coverage Starts
        driver.execute_script("window.open('https://nvrobot.cav-test.com/instument0.2/swapp/jscoverage.html', 'JSCoverInvertedMode')")
        driver.switch_to.window(driver.window_handles[-1])
        time.sleep(1)
        jsonVal = driver.execute_script("return window.jscoverage_serializeCoverageToJSON()")
        time.sleep(3)
        jd = json.loads(jsonVal)
        finalJson = json.dumps(jd)
        f = open("/home/cavisson/work/robotSuite/swjscoverFile/createsessionJS1.json", "w")
        f.write(finalJson)
        f.close()
        driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js18.png")
        driver.switch_to.window(driver.window_handles[0])
        #Code for js coverage Ends      

        proxy.new_har('cartRT2', options={"captureContent":True, "captureHeaders": True})
        #proxy.new_har('homePage')
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/cart.html')
        driver.maximize_window()
        time.sleep(5) 
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        time.sleep(1)
        #pprint(proxy.har) # returns [] if using headless
        cartRT2Har = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/cartRT2.har", "w")
        f.write(cartRT2Har)
        f.close()
        proxy.new_har('checkoutRT', options={"captureContent":True, "captureHeaders":False})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/checkout.html')
        driver.maximize_window()
        time.sleep(10) 
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        checkoutRTHar = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/checkoutRT.har", "w")
        f.write(checkoutRTHar)
        f.close()

        #Code for js coverage Starts
        driver.execute_script("window.open('https://nvrobot.cav-test.com/instument0.2/swapp/jscoverage.html', 'JSCoverInvertedMode')")
        driver.switch_to.window(driver.window_handles[-1])
        time.sleep(1)
        jsonVal = driver.execute_script("return window.jscoverage_serializeCoverageToJSON()")
        time.sleep(3)
        jd = json.loads(jsonVal)
        finalJson = json.dumps(jd)
        f = open("/home/cavisson/work/robotSuite/swjscoverFile/createsessionJS2.json", "w")
        f.write(finalJson)
        f.close()
        driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js19.png")
        driver.switch_to.window(driver.window_handles[0])
        #Code for js coverage Ends      

        driver.close()
        mobserver.stop()
#createsessionJS()
def createsessionUT():
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        p = get_free_tcp_port()
        newPort = {'port': p}
        #newPort = {'port': 8082}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()

        chrome_options = webdriver.ChromeOptions()

#       user_agent = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.50 Safari/537.36'
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
#       chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        #chrome_options.add_argument('--window-size=800,600')
        #chrome_options.add_argument("--user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36")

        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))

        # Disable Images
        #prefs = {
        #"profile.managed_default_content_settings.images":2
        #} 
        #chrome_options.add_experimental_option("prefs",prefs)
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True

        #driver = webdriver.Chrome(executable_path='/home/cavisson/work/robotSuite/chromedriver',chrome_options=chrome_options,desired_capabilities=capabilities)
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)
        #proxy.new_har('google', options={"captureContent":True, "captureBinaryContent":True})
        proxy.new_har('homeUT', options={"captureContent":True, "captureHeaders":False})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/index.html')
        driver.maximize_window()
        time.sleep(10)
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        time.sleep(2)
        homeUTHar = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/homeUT.har", "w")
        f.write(homeUTHar)
        f.close()
        proxy.new_har('cartUT', options={"captureContent":True, "captureHeaders":False})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/cart.html')
        driver.maximize_window()
        time.sleep(5)
        btnDiv = driver.find_element_by_css_selector("#dwEvent")
        btnClick = driver.find_element_by_css_selector("button#dwEvent")
        actions = ActionChains(driver)
        actions.move_to_element(btnDiv)
        actions.click(btnClick)
        actions.perform()
        time.sleep(1)
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        time.sleep(2)
        cartUTHar = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/cartUT.har", "w")
        f.write(cartUTHar)
        f.close()
        #Code for js coverage Starts
        driver.execute_script("window.open('https://nvrobot.cav-test.com/instument0.2/swapp/jscoverage.html', 'JSCoverInvertedMode')")
        driver.switch_to.window(driver.window_handles[-1])
        time.sleep(1)
        jsonVal = driver.execute_script("return window.jscoverage_serializeCoverageToJSON()")
        time.sleep(3)
        jd = json.loads(jsonVal)
        finalJson = json.dumps(jd)
        f = open("/home/cavisson/work/robotSuite/swjscoverFile/createsessionUT.json", "w")
        f.write(finalJson)
        f.close()
        driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js20.png")
        driver.switch_to.window(driver.window_handles[0])
        #Code for js coverage Ends      

        driver.close()
        mobserver.stop()

def createsessionVR():
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        p = get_free_tcp_port()
        newPort = {'port': p}
        #newPort = {'port': 8082}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()
        chrome_options = webdriver.ChromeOptions()
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)

        proxy.new_har('checkoutVR', options={"captureContent":True, "captureHeaders":True})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/checkout.html')
        #print (driver.get_window_size())
        time.sleep(1)
        driver.execute_script("window.scrollBy(0,500)")
        wait = WebDriverWait(driver, 10)
        element = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, '[name="fname"]')))
        driver.find_element_by_css_selector("[name='fname']").send_keys("Robot")
        driver.find_element_by_css_selector("[name='lname']").send_keys("Data")
        driver.find_element_by_css_selector("[name='street']").send_keys("Noida")
        driver.find_element_by_css_selector("[name='zip']").send_keys("201301")
        driver.find_element_by_css_selector("[name='tel']").send_keys("9876543210")
        driver.find_element_by_css_selector("[name='email']").send_keys("robot@cavisson.com")
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
       # print("h3")
        driver.find_element_by_id("ocbtn").click()
        time.sleep(3)
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        sid=driver.execute_script("return window.CAVNV.sid;")
       # print(sid)
        checkoutVRHar = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/checkoutVR.har", "w")
        f.write(checkoutVRHar)
        f.close()
        #Code for js coverage Starts
        driver.execute_script("window.open('https://nvrobot.cav-test.com/instument0.2/swapp/jscoverage.html', 'JSCoverInvertedMode')")
        driver.switch_to.window(driver.window_handles[-1])
        time.sleep(1)
        jsonVal = driver.execute_script("return window.jscoverage_serializeCoverageToJSON()")
        time.sleep(3)
        jd = json.loads(jsonVal)
        finalJson = json.dumps(jd)
        f = open("/home/cavisson/work/robotSuite/swjscoverFile/createsessionVR.json", "w")
        f.write(finalJson)
        f.close()
        driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js21.png")
        driver.switch_to.window(driver.window_handles[0])
        #Code for js coverage Ends      

        driver.close()
        mobserver.stop()


def getVersion():
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        p = get_free_tcp_port()
        newPort = {'port': p}
        #newPort = {'port': 8082}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()
        chrome_options = webdriver.ChromeOptions()
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)

        proxy.new_har('cartAjax', options={"captureContent":True, "captureHeaders":True})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/index.html')
        driver.maximize_window()
        time.sleep(5)
        v= driver.execute_script("return window.CAVNV.version;")
        t= v.split("_")[1]
        v2= v.split("_")[0]
        tv= int(str(t),16)
        cV= driver.execute_script("return window.CAVNV.config.version;")
        #v = open("agentVersionfile.txt", "w")
        #v.write(cv)
        #v.close()
        print(str(v))
        print(str(cV))
        version= str(v2)+"_"+str(tv)
        print("version is ->"+version)
        cVersion= int(str(cV),16)
        #Code for js coverage Starts
        driver.execute_script("window.open('https://nvrobot.cav-test.com/instument0.2/swapp/jscoverage.html', 'JSCoverInvertedMode')")
        driver.switch_to.window(driver.window_handles[-1])
        time.sleep(1)
        jsonVal = driver.execute_script("return window.jscoverage_serializeCoverageToJSON()")
        time.sleep(3)
        jd = json.loads(jsonVal)
        finalJson = json.dumps(jd)
        f = open("/home/cavisson/work/robotSuite/swjscoverFile/getVersion.json", "w")
        f.write(finalJson)
        f.close()
        driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js22.png")
        driver.switch_to.window(driver.window_handles[0])
        #Code for js coverage Ends      

        driver.close()
        mobserver.stop()
        d = []
        d.append(version)
        d.append(cVersion)
        return d

def addDomIframe():
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        p = get_free_tcp_port()
        newPort = {'port': p}
        #newPort = {'port': 8082}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()
        chrome_options = webdriver.ChromeOptions()
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)

        proxy.new_har('pdp', options={"captureContent":True, "captureHeaders":True})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/product-single.html')
        driver.maximize_window()
        time.sleep(5) 
        driver.execute_script("window.scrollBy(0,2000)");
        btnDiv= driver.find_element_by_id("addFram")
        btnClick= driver.find_element_by_id("addFram")
        actions = ActionChains(driver)
        actions.move_to_element(btnDiv)
        actions.click(btnClick)
        actions.perform()
        driver.save_screenshot("ifram.png")
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        pdpHar = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/pdpIframe.har", "w")
        f.write(pdpHar)
        f.close()
        #Code for js coverage Starts
        driver.execute_script("window.open('https://nvrobot.cav-test.com/instument0.2/swapp/jscoverage.html', 'JSCoverInvertedMode')")
        driver.switch_to.window(driver.window_handles[-1])
        time.sleep(1)
        jsonVal = driver.execute_script("return window.jscoverage_serializeCoverageToJSON()")
        time.sleep(3)
        jd = json.loads(jsonVal)
        finalJson = json.dumps(jd)
        f = open("/home/cavisson/work/robotSuite/swjscoverFile/addDomIframe.json", "w")
        f.write(finalJson)
        f.close()
        driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js22.png")
        driver.switch_to.window(driver.window_handles[0])
        #Code for js coverage Ends      

        driver.close()
        mobserver.stop()

def callbackSession():
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        p = get_free_tcp_port()
        newPort = {'port': p}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()
        chrome_options = webdriver.ChromeOptions()
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)

        proxy.new_har('cartAjax', options={"captureContent":True, "captureHeaders":True})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/checkout.html')
        #print (driver.get_window_size())
        time.sleep(1)
        driver.execute_script("window.scrollBy(0,500)")
        wait = WebDriverWait(driver, 10)
        element = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, '[name="fname"]')))
        driver.find_element_by_css_selector("[name='fname']").send_keys("Robot")
        driver.find_element_by_css_selector("[name='lname']").send_keys("Data")
        driver.find_element_by_css_selector("[name='street']").send_keys("Noida")
        driver.find_element_by_css_selector("[name='zip']").send_keys("201301")
        driver.find_element_by_css_selector("[name='tel']").send_keys("9876543210")
        driver.find_element_by_css_selector("[name='email']").send_keys("robot@cavisson.com")
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
       # print("h3")
        time.sleep(2)

        cartAjaxHar = json.dumps(proxy.har,ensure_ascii=False).encode('utf8')
        f = open("/home/cavisson/work/robotSuite/harfile/callback.har", "w")
        f.write(cartAjaxHar)
        f.close()
        #Code for js coverage Starts
        driver.execute_script("window.open('https://nvrobot.cav-test.com/instument0.2/swapp/jscoverage.html', 'JSCoverInvertedMode')")
        driver.switch_to.window(driver.window_handles[-1])
        time.sleep(1)
        jsonVal = driver.execute_script("return window.jscoverage_serializeCoverageToJSON()")
        time.sleep(3)
        jd = json.loads(jsonVal)
        finalJson = json.dumps(jd)
        f = open("/home/cavisson/work/robotSuite/swjscoverFile/callbackSession.json", "w")
        f.write(finalJson)
        f.close()
        driver.save_screenshot("/home/cavisson/work/webapps/nvbackend/results/snapshots/js23.png")
        driver.switch_to.window(driver.window_handles[0])
        #Code for js coverage Ends      

        driver.close()
        mobserver.stop()

def createsessionBP():
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        newPort = {'port': 8082}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()
        chrome_options = webdriver.ChromeOptions()
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)

        proxy.new_har('homeBP', options={"captureContent":True, "captureHeaders":True})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/index.html')
        #print (driver.get_window_size())
        time.sleep(1)
        driver.execute_script("window.scrollBy(0,500)")
        wait = WebDriverWait(driver, 10)
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        driver.save_screenshot("a.png")
       # print("h3")
        time.sleep(3)
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        sid=driver.execute_script("return window.CAVNV.sid;")
       # print(sid)
        homeBPHar = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/homeBP.har", "w")
        f.write(homeBPHar)
        f.close()
        proxy.new_har('cartBP', options={"captureContent":True, "captureHeaders":True})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/cart.html')
        #print (driver.get_window_size())
        time.sleep(1)
        driver.execute_script("window.scrollBy(0,500)")
        wait = WebDriverWait(driver, 10)
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        driver.save_screenshot("a.png")
       #print("h3")
        time.sleep(3)
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        sid=driver.execute_script("return window.CAVNV.sid;")
       # print(sid)
        cartBPHar = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/cartBP.har", "w")
        f.write(cartBPHar)
        f.close()
        proxy.new_har('checkoutBP', options={"captureContent":True, "captureHeaders":True})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/checkout.html')
        #print (driver.get_window_size())
        time.sleep(1)
        driver.execute_script("window.scrollBy(0,500)")
        wait = WebDriverWait(driver, 10)
        driver.execute_script("window.cav_nv_log_event('RobotEvent',{})")
        driver.execute_script("window.cav_nv_log_event('RobotEvent',{'msg':'Robot Event With Message'})")
        driver.save_screenshot("a.png")
       # print("h3")
        time.sleep(3)
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        sid=driver.execute_script("return window.CAVNV.sid;")
       # print(sid)
        checkoutBPHar = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/checkoutBP.har", "w")
        f.write(checkoutBPHar)
        f.close()
        proxy.new_har('confirmBP', options={"captureContent":True, "captureHeaders":True})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/orderConfirmation.html')
        #print (driver.get_window_size())
        time.sleep(1)
        driver.execute_script("window.scrollBy(0,500)")
        wait = WebDriverWait(driver, 10)
        driver.save_screenshot("a.png")
       # print("h3")
        time.sleep(3)
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        sid=driver.execute_script("return window.CAVNV.sid;")
       # print(sid)
        confirmBPHar = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/confirmBP.har", "w")
        f.write(confirmBPHar)
        f.close()
        driver.close()
        mobserver.stop()

def createsessionCP():
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        newPort = {'port': 8082}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()
        chrome_options = webdriver.ChromeOptions()
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)
        proxy.new_har('checkpointCP', options={"captureContent":True, "captureHeaders":False})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/cart.html')
        driver.maximize_window()
        time.sleep(10)
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        time.sleep(2)
        checkpointCPHar = json.dumps(proxy.har,ensure_ascii=False).encode('utf8')
        f = open("/home/cavisson/work/robotSuite/harfile/checkpointCP.har", "w")
        f.write(checkpointCPHar)
        f.close()
        driver.close()
        mobserver.stop()

def createsessionFo():
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        newPort = {'port': 8082}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()

        chrome_options = webdriver.ChromeOptions()

#       user_agent = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.50 Safari/537.36'
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
#       chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)
        proxy.new_har('cartFO', options={"captureContent":True, "captureHeaders":False})
        driver.get('https://nvrobot.cav-test.com/instument0.2/swapp/cart.html')
        driver.maximize_window()
        time.sleep(5)
        btnDiv = driver.find_element_by_css_selector("#dwEvent")
        btnClick = driver.find_element_by_css_selector("button#dwEvent")
        actions = ActionChains(driver)
        actions.move_to_element(btnDiv)
        actions.click(btnClick)
        actions.perform()
        time.sleep(2)
        actions = ActionChains(driver)
        actions.move_to_element(btnDiv)
        actions.click(btnClick)
        actions.perform()
        driver.execute_script("window.CAVNV.flush_all();")
        driver.execute_script("window.CAVNV.sbqueue.flush();")
        time.sleep(2)
        cartFOHar = json.dumps(proxy.har)
        f = open("/home/cavisson/work/robotSuite/harfile/cartFO.har", "w")
        f.write(cartFOHar)
        f.close()
        driver.close()
        mobserver.stop()



#This should be last method that will kill the browsermobproxy
def check_kill_process(pstring):
    for line in os.popen("ps ax | grep " + pstring + " | grep -v grep"):
        fields = line.split()
        pid = fields[0]
        os.kill(int(pid), signal.SIGKILL)


#check_kill_process("browsermo")
#check_kill_process("chrome")
#createSession()

