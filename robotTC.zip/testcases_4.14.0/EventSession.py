from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium import webdriver
from Selenium2Library import Selenium2Library
from browsermobproxy import Server
from pprint import pprint
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import json
import time
import os, signal
import socket

def sessioneventrtc():
        MOBPATH = "/home/cavisson/work/robotSuite/browsermob-proxy-2.1.4/bin/browsermob-proxy"
        newPort = {'port': 8082}
        mobserver = Server(MOBPATH, options=newPort)
        mobserver.start()
        proxy = mobserver.create_proxy()

        chrome_options = webdriver.ChromeOptions()

#       user_agent = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.50 Safari/537.36'
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        chrome_options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36')
        chrome_options.add_argument('--headless')
#       chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument("--proxy-server={0}".format(proxy.proxy))
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True
        driver = webdriver.Chrome(chrome_options=chrome_options,desired_capabilities=capabilities)
        proxy.new_har('eventrtc', options={"captureContent":True, "captureHeaders":False})
        sT=None
        try:
          driver.get('http://10.10.30.247:9050/instument0.2/index.html')
          driver.maximize_window()
          time.sleep(7)
          driver.execute_script("cav_nv_log_event('netvision', 12);")
#       driver.execute_script("console.log('robotlog');")
          time.sleep(7)
          sT= driver.execute_script("return window.CAVNV.session_start_time;")
          print(sT)
          driver.execute_script("window.CAVNV.flush_all();")
          driver.execute_script("window.CAVNV.sbqueue.flush();")
          time.sleep(2)
          eventrtcHar = json.dumps(proxy.har)
          f = open("/home/cavisson/work/robotSuite/harfile/eventrtc.har", "w")
          f.write(eventrtcHar)
          f.close()
          driver.close()
          mobserver.stop()
        except Exception as e:
            print(e)
        finally:
            mobserver.stop()
        return sT

def parseHarData(harName,requestName,*args):
        harName =  "/home/cavisson/work/robotSuite/harfile/"+harName+".har"
        #harName =  "/home/cavisson/work/robotSuite/harfile/HomePageCSI.har"
        print (harName)
        # Opening JSON file 
        f = open(harName,)
        data = json.load(f)
        f.close()
        entryList= data["log"]["entries"];
        print (len(entryList))
        hData = [];
        for entry in entryList:
            urlVal = entry["request"]["url"]
            if requestName in urlVal:
                 print (urlVal)
                 if len(args) == 0:
                         rStatus = entry["response"]["status"]
                         d = [urlVal,rStatus]
                         hData.append(d)
                 else:
                        searchParameter = args[0]
                        rParam = entry["request"][searchParameter]
                        print(rParam)
                        d = [urlVal,rParam]
                        hData.append(d)
        return hData


def parseHarDataWithData(harName,requestName,*args):
        harName =  "/home/cavisson/work/robotSuite/harfile/"+harName+".har"
        #harName =  "/home/cavisson/work/robotSuite/harfile/HomePageWithPostData.har"
        print (harName)
        sp = len(args)
        # Opening JSON file 
        f = open(harName,)
        data = json.load(f)
        f.close()
        entryList= data["log"]["entries"];
        print (len(entryList))
        hData = [];
        for entry in entryList:
            urlVal = entry["request"]["url"]
            if requestName in urlVal:
                 #print (urlVal)
                 rStatus = entry["request"]["postData"]["text"]
                 if sp > 0:
                        print("in if")
                        searchPattern = args[0]
                        if searchPattern in rStatus:
                                 d = [urlVal,rStatus]
                                 hData.append(d)
                 else:
                    print("in else")
                    d = [urlVal,rStatus]
                    hData.append(d)

        return hData


#This should be last method that will kill the browsermobproxy
def check_kill_process(pstring):
     for line in os.popen("ps ax | grep " + pstring + " | grep -v grep"):
        fields = line.split()
        pid = fields[0]
        os.kill(int(pid), signal.SIGKILL)
sessioneventrtc()
